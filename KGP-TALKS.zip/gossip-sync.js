const dgram = require('dgram');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

class GossipSync {
  constructor(options = {}) {
    this.port = options.port || 41234;
    this.broadcastPort = options.broadcastPort || 41235;
    this.filePath = options.filePath || path.join(__dirname, 'storage', 'msg.json');
    this.gossipInterval = options.gossipInterval || 5000; // 5 seconds
    this.socket = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    
    this.fileHash = null;
    this.messages = [];
    this.peerId = this.generatePeerId();
    this.knownPeers = new Map(); // peerId -> lastSeen
  }

  generatePeerId() {
    return crypto.randomBytes(8).toString('hex');
  }

  async init() {
    // Ensure storage directory exists
    const dir = path.dirname(this.filePath);
    try {
      await fs.mkdir(dir, { recursive: true });
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
    }

    // Load existing messages or create empty file
    await this.loadMessages();

    // Setup UDP socket
    this.socket.on('message', (msg, rinfo) => this.handleMessage(msg, rinfo));
    this.socket.on('error', (err) => console.error('Socket error:', err));
    
    this.socket.bind(this.broadcastPort, () => {
      this.socket.setBroadcast(true);
      console.log(`Gossip sync listening on port ${this.broadcastPort}`);
      console.log(`Peer ID: ${this.peerId}`);
    });

    // Start gossip protocol
    this.startGossip();

    // Watch file for changes
    this.watchFile();
  }

  async loadMessages() {
    try {
      const data = await fs.readFile(this.filePath, 'utf8');
      this.messages = JSON.parse(data);
      this.fileHash = this.calculateHash(this.messages);
      console.log(`Loaded ${this.messages.length} messages`);
    } catch (err) {
      if (err.code === 'ENOENT') {
        this.messages = [];
        await this.saveMessages();
        console.log('Created new msg.json file');
      } else {
        throw err;
      }
    }
  }

  async saveMessages() {
    const data = JSON.stringify(this.messages, null, 2);
    await fs.writeFile(this.filePath, data, 'utf8');
    this.fileHash = this.calculateHash(this.messages);
  }

  calculateHash(messages) {
    const str = JSON.stringify(messages);
    return crypto.createHash('sha256').update(str).digest('hex');
  }

  watchFile() {
    let timeout;
    fs.watch(path.dirname(this.filePath), async (eventType, filename) => {
      if (filename === path.basename(this.filePath)) {
        clearTimeout(timeout);
        timeout = setTimeout(async () => {
          const oldHash = this.fileHash;
          await this.loadMessages();
          if (this.fileHash !== oldHash) {
            console.log('File changed locally, broadcasting update');
            this.broadcastAnnouncement();
          }
        }, 100);
      }
    });
  }

  startGossip() {
    setInterval(() => {
      this.broadcastAnnouncement();
      this.cleanupPeers();
    }, this.gossipInterval);
  }

  broadcastAnnouncement() {
    const announcement = {
      type: 'ANNOUNCE',
      peerId: this.peerId,
      hash: this.fileHash,
      messageCount: this.messages.length,
      timestamp: Date.now()
    };

    const buffer = Buffer.from(JSON.stringify(announcement));
    this.socket.send(buffer, 0, buffer.length, this.broadcastPort, '255.255.255.255', (err) => {
      if (err) console.error('Broadcast error:', err);
    });
  }

  async handleMessage(msg, rinfo) {
    try {
      const data = JSON.parse(msg.toString());
      
      // Ignore messages from self
      if (data.peerId === this.peerId) return;

      // Update known peers
      this.knownPeers.set(data.peerId, Date.now());

      switch (data.type) {
        case 'ANNOUNCE':
          await this.handleAnnouncement(data, rinfo);
          break;
        case 'REQUEST':
          await this.handleRequest(data, rinfo);
          break;
        case 'RESPONSE':
          await this.handleResponse(data, rinfo);
          break;
      }
    } catch (err) {
      console.error('Error handling message:', err);
    }
  }

  async handleAnnouncement(data, rinfo) {
    console.log(`Peer ${data.peerId.substring(0, 8)} has ${data.messageCount} messages (hash: ${data.hash.substring(0, 8)}...)`);

    // If peer has different data, request it
    if (data.hash !== this.fileHash) {
      console.log('Hash mismatch detected, requesting data...');
      
      const request = {
        type: 'REQUEST',
        peerId: this.peerId,
        timestamp: Date.now()
      };

      const buffer = Buffer.from(JSON.stringify(request));
      this.socket.send(buffer, 0, buffer.length, this.broadcastPort, rinfo.address);
    }
  }

  async handleRequest(data, rinfo) {
    console.log(`Peer ${data.peerId.substring(0, 8)} requesting data`);
    
    const response = {
      type: 'RESPONSE',
      peerId: this.peerId,
      messages: this.messages,
      hash: this.fileHash,
      timestamp: Date.now()
    };

    const buffer = Buffer.from(JSON.stringify(response));
    
    // Send response directly to requester
    this.socket.send(buffer, 0, buffer.length, this.broadcastPort, rinfo.address);
  }

  async handleResponse(data, rinfo) {
    console.log(`Received data from peer ${data.peerId.substring(0, 8)}`);
    
    // Merge messages (append-only with deduplication)
    const merged = await this.mergeMessages(data.messages);
    
    if (merged) {
      await this.saveMessages();
      console.log(`Merged messages. Total: ${this.messages.length}`);
    }
  }

  async mergeMessages(incomingMessages) {
    const existingIds = new Set(this.messages.map(m => m.id));
    let added = false;

    for (const msg of incomingMessages) {
      if (!existingIds.has(msg.id)) {
        this.messages.push(msg);
        added = true;
      }
    }

    // Sort by time
    if (added) {
      this.messages.sort((a, b) => (a.time || 0) - (b.time || 0));
    }

    return added;
  }

  cleanupPeers() {
    const now = Date.now();
    const timeout = this.gossipInterval * 3;
    
    for (const [peerId, lastSeen] of this.knownPeers.entries()) {
      if (now - lastSeen > timeout) {
        this.knownPeers.delete(peerId);
        console.log(`Peer ${peerId.substring(0, 8)} timed out`);
      }
    }
  }

  // Public method to add a message programmatically
  async addMessage(content, type = 'text', metadata = {}) {
    const message = {
      id: crypto.createHash('sha256').update(`${Date.now()}-${content}-${this.peerId}`).digest('hex'),
      type,
      content,
      time: Math.floor(Date.now() / 1000), // Unix timestamp in seconds
      ...metadata
    };

    this.messages.push(message);
    await this.saveMessages();
    this.broadcastAnnouncement();
    
    return message;
  }

  getMessages() {
    return this.messages;
  }

  stop() {
    this.socket.close();
    console.log('Gossip sync stopped');
  }
}

// Example usage
async function main() {
  const sync = new GossipSync({
    filePath: path.join(__dirname, 'storage', 'msg.json'),
    gossipInterval: 5000 // Broadcast every 5 seconds
  });

  await sync.init();

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\nShutting down...');
    sync.stop();
    process.exit(0);
  });
}

// Run if executed directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = GossipSync;