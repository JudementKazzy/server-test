@echo off
title DEBUG - KGP Talks Launcher
color 0E

echo ============================================
echo   DEBUG MODE - KGP TALKS LAUNCHER
echo ============================================
echo.

echo Current Directory:
cd
echo.

echo Checking if Node.js is installed...
where node
echo Node.js Exit Code: %ERRORLEVEL%
echo.

echo Checking for server file...
if exist "server-no-express.js" (
    echo [OK] server-no-express.js found
) else (
    echo [ERROR] server-no-express.js NOT found
)
echo.

echo Checking for package.json...
if exist "package.json" (
    echo [OK] package.json found
) else (
    echo [ERROR] package.json NOT found
)
echo.

echo Checking for node_modules...
if exist "node_modules\" (
    echo [OK] node_modules folder found
) else (
    echo [WARNING] node_modules folder NOT found
    echo You need to run: npm install
)
echo.

echo Files in current directory:
dir /b
echo.

echo ============================================
echo   DEBUG COMPLETE
echo ============================================
echo.
echo If you see errors above, that's the problem!
echo.
pause