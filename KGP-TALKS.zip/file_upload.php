<?php
/**
 * Generate a unique anonymous message ID
 */
function generateMessageId($content, $timestamp) {
    $random = bin2hex(random_bytes(16));
    $data = $content . $timestamp . $random;
    return hash('sha256', $data);
}

/**
 * Round timestamp to nearest interval (for anonymity)
 */
function roundTimestamp($timestamp, $interval = 30) {
    return floor($timestamp / $interval) * $interval;
}

/**
 * Check if message ID already exists (deduplication)
 */
function messageExists($messages, $id) {
    foreach ($messages as $msg) {
        if (isset($msg['id']) && $msg['id'] === $id) {
            return true;
        }
    }
    return false;
}

/**
 * Simplify MIME type to basic category
 */
function simplifyMimeType($mimeType) {
    $parts = explode('/', $mimeType);
    return $parts[0]; // Returns 'image', 'video', 'audio', 'application', etc.
}

if(isset($_FILES["file"])) {
    error_log("=== FILE UPLOAD START ===");
    $file = $_FILES["file"];
    error_log("File name: " . $file["name"]);
   
    // Check for upload errors
    if ($file["error"] !== UPLOAD_ERR_OK) {
        http_response_code(500);
        echo "Upload error: " . $file["error"];
        exit;
    }
   
    // Generate unique filename to prevent conflicts and enhance anonymity
    $extension = pathinfo($file["name"], PATHINFO_EXTENSION);
    $uniqueFileName = bin2hex(random_bytes(16)) . '.' . $extension;
   
    $target = "storage/" . $uniqueFileName;
   
    // Ensure storage directory exists
    if (!is_dir("storage")) {
        mkdir("storage", 0755, true);
    }
   
    if (!move_uploaded_file($file["tmp_name"], $target)) {
        error_log("Failed to move uploaded file to: " . $target);
        http_response_code(500);
        echo "Failed to upload file";
        exit;
    }
    
    error_log("File uploaded successfully to: " . $target);
   
    // Round timestamp for anonymity
    $time = time();
    $roundedTime = roundTimestamp($time, 30);
   
    // Alternative to mime_content_type for Windows compatibility
    $type = 'application'; // default
    if (function_exists('mime_content_type')) {
        $fullMimeType = mime_content_type($target);
        $type = simplifyMimeType($fullMimeType);
    } else {
        // Fallback: detect type from extension
        $ext = strtolower($extension);
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'])) {
            $type = 'image';
        } elseif (in_array($ext, ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm'])) {
            $type = 'video';
        } elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'])) {
            $type = 'audio';
        } elseif (in_array($ext, ['txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx'])) {
            $type = 'application';
        } else {
            $type = 'application';
        }
    }
   
    // Generate unique anonymous ID
    $messageId = generateMessageId($uniqueFileName, $roundedTime);
   
    // Read existing messages from msg.json
    $msgPath = "storage/msg.json";
    $data = [];
    
    error_log("Reading from: " . $msgPath);
    
    if (file_exists($msgPath)) {
        $content = file_get_contents($msgPath);
        if ($content !== false) {
            error_log("File content: " . $content);
            $data = json_decode($content, true);
            if ($data === null) {
                error_log("JSON decode failed: " . json_last_error_msg());
                // JSON decode failed, start fresh
                $data = [];
            } else {
                error_log("Successfully decoded " . count($data) . " existing messages");
            }
        }
    } else {
        error_log("msg.json does not exist, will create new");
    }
   
    // Check for duplicates
    if (messageExists($data, $messageId)) {
        unlink($target);
        echo "DUPLICATE";
        exit;
    }
   
    // Create new file message
    $newMessage = [
        "id" => $messageId,
        "type" => $type,
        "content" => $uniqueFileName,
        "time" => $roundedTime
    ];
   
    // Add to beginning of array
    array_unshift($data, $newMessage);
   
    // Debug: Log what we're trying to save
    error_log("Attempting to save to: " . realpath($msgPath));
    error_log("Data to save: " . print_r($data, true));
    
    // Save to msg.json with proper error handling
    $jsonData = json_encode($data, JSON_PRETTY_PRINT);
    
    if ($jsonData === false) {
        http_response_code(500);
        echo "Failed to encode JSON: " . json_last_error_msg();
        exit;
    }
    
    // Check if file is writable before attempting write
    if (file_exists($msgPath) && !is_writable($msgPath)) {
        http_response_code(500);
        echo "msg.json is not writable. Permissions: " . substr(sprintf('%o', fileperms($msgPath)), -4);
        exit;
    }
    
    $writeResult = file_put_contents($msgPath, $jsonData, LOCK_EX);
    
    if ($writeResult === false) {
        http_response_code(500);
        $error = error_get_last();
        echo "Failed to write to msg.json. Error: " . ($error['message'] ?? 'Unknown');
        exit;
    }
    
    // Verify the file was written
    clearstatcache();
    $newContent = file_get_contents($msgPath);
    $newData = json_decode($newContent, true);
    
    if (count($newData) !== count($data)) {
        http_response_code(500);
        echo "Write verification failed. Expected " . count($data) . " messages, found " . count($newData);
        exit;
    }
    
    echo "OK - Wrote " . $writeResult . " bytes";
} else {
    http_response_code(400);
    echo "No file uploaded";
}
?>