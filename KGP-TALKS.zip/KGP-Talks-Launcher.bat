@echo off
title KGP Talks - Server
color 0A

REM Check for admin privileges
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ========================================
    echo    ADMIN PRIVILEGES REQUIRED
    echo  ========================================
    echo.
    echo  This script needs to run as Administrator
    echo  to configure the firewall for P2P sync.
    echo.
    echo  Right-click this file and select:
    echo  "Run as administrator"
    echo.
    pause
    exit /b 1
)

REM Change to script directory
cd /d "%~dp0"
cls

echo.
echo  ========================================
echo        KGP TALKS - P2P CHAT LAUNCHER
echo  ========================================
echo.

REM Check Node.js
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js not found!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b 1
)
echo [OK] Node.js: 
node --version
echo.

REM Configure Firewall for P2P (UDP Port 41235)
echo [CHECKING] Firewall rules...
netsh advfirewall firewall show rule name="KGP Talks P2P Sync" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [CONFIGURING] Adding firewall rule for UDP port 41235...
    netsh advfirewall firewall add rule name="KGP Talks P2P Sync" dir=in action=allow protocol=UDP localport=41235 >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        echo [OK] Firewall configured successfully
    ) else (
        echo [WARNING] Could not configure firewall automatically
        echo You may need to manually allow UDP port 41235
    )
) else (
    echo [OK] Firewall rule already exists
)
echo.

REM Check dependencies
if not exist "node_modules\formidable\" (
    echo [INSTALLING] Dependencies...
    call npm install formidable
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Failed to install dependencies
        pause
        exit /b 1
    )
)
echo [OK] Dependencies ready
echo.

REM Create storage folder
if not exist "storage\" mkdir storage

REM Get IP address
set LOCAL_IP=Not found
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4" ^| findstr /v "127.0.0.1"') do (
    set LOCAL_IP=%%a
    goto :ip_found
)
:ip_found
set LOCAL_IP=%LOCAL_IP:~1%

cls
echo.
echo  ========================================
echo         SERVER RUNNING
echo  ========================================
echo.
echo  [LOCAL ACCESS]
echo    http://localhost:3000
echo.
echo  [NETWORK ACCESS - Share with friends]
echo    http://%LOCAL_IP%:3000
echo.
echo  [P2P GOSSIP SYNC]
echo    UDP Port: 41235 (Configured)
echo    Status: Active
echo.
echo  ========================================
echo.
echo  Opening browser in 3 seconds...
echo.
echo  Press Ctrl+C to stop server
echo  ========================================
echo.

REM Wait 3 seconds then open browser
ping 127.0.0.1 -n 4 >nul
start http://localhost:3000

REM Start server - this keeps window open
node server-no-express.js

REM Only reaches here if server crashes
echo.
echo [ERROR] Server stopped unexpectedly!
pause