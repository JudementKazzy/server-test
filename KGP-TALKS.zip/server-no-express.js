const http = require('http');
const fs = require('fs').promises;
const path = require('path');
const url = require('url');
const crypto = require('crypto');
const { IncomingForm } = require('formidable');
const GossipSync = require('./gossip-sync');

// Initialize Gossip Sync
const gossipSync = new GossipSync({
  filePath: path.join(__dirname, 'storage', 'msg.json'),
  gossipInterval: 5000,
  port: 41234,
  broadcastPort: 41235
});

// Start gossip sync
gossipSync.init().then(() => {
  console.log('Gossip sync initialized');
}).catch(err => {
  console.error('Failed to initialize gossip sync:', err);
});

// Helper functions
function generateMessageId(content, timestamp) {
  const random = crypto.randomBytes(16).toString('hex');
  const data = content + timestamp + random;
  return crypto.createHash('sha256').update(data).digest('hex');
}

function roundTimestamp(timestamp, interval = 30) {
  return Math.floor(timestamp / interval) * interval;
}

function messageExists(messages, id) {
  return messages.some(msg => msg.id === id);
}

// Helper to parse URL-encoded body
async function parseUrlEncoded(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk.toString());
    req.on('end', () => {
      const params = new URLSearchParams(body);
      const result = {};
      for (const [key, value] of params) {
        result[key] = value;
      }
      resolve(result);
    });
    req.on('error', reject);
  });
}

// Helper to send response
function send(res, statusCode, contentType, data) {
  res.writeHead(statusCode, { 'Content-Type': contentType });
  res.end(data);
}

function sendJSON(res, statusCode, data) {
  send(res, statusCode, 'application/json', JSON.stringify(data));
}

// Helper to serve static files
async function serveFile(res, filePath) {
  try {
    const ext = path.extname(filePath).toLowerCase();
    const contentTypes = {
      '.html': 'text/html',
      '.js': 'text/javascript',
      '.css': 'text/css',
      '.json': 'application/json',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.svg': 'image/svg+xml',
      '.mp4': 'video/mp4',
      '.webm': 'video/webm',
      '.mp3': 'audio/mpeg',
      '.wav': 'audio/wav',
      '.pdf': 'application/pdf',
    };

    const content = await fs.readFile(filePath);
    res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'application/octet-stream' });
    res.end(content);
  } catch (err) {
    if (err.code === 'ENOENT') {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 Not Found');
    } else {
      console.error('Error serving file:', err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('500 Internal Server Error');
    }
  }
}

// Create HTTP server
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  try {
    // PHP Replacement: save_message.php
    if (pathname === '/save_message.php' && req.method === 'POST') {
      const body = await parseUrlEncoded(req);
      const text = body.text?.trim();

      if (!text) {
        send(res, 400, 'text/plain', 'EMPTY');
        return;
      }

      const time = Math.floor(Date.now() / 1000);
      const roundedTime = roundTimestamp(time, 30);
      const messageId = generateMessageId(text, roundedTime);

      const messages = gossipSync.getMessages();

      if (messageExists(messages, messageId)) {
        send(res, 200, 'text/plain', 'DUPLICATE');
        return;
      }

      // Add message at the beginning (like PHP unshift)
      const message = {
        id: messageId,
        type: 'text',
        content: text,
        time: roundedTime
      };

      gossipSync.messages.unshift(message);
      await gossipSync.saveMessages();
      
      console.log('Text message added:', text.substring(0, 50));
      send(res, 200, 'text/plain', 'OK');
    }
    // PHP Replacement: get_message.php
    else if (pathname === '/get_message.php' && req.method === 'GET') {
      const messages = gossipSync.getMessages();
      sendJSON(res, 200, messages);
    }
    // PHP Replacement: clear_history.php
    else if (pathname === '/clear_history.php' && req.method === 'POST') {
      gossipSync.messages = [];
      await gossipSync.saveMessages();
      send(res, 200, 'text/plain', 'OK');
    }
    // PHP Replacement: file_upload.php
    else if (pathname === '/file_upload.php' && req.method === 'POST') {
      const storageDir = path.join(__dirname, 'storage');
      
      // Ensure storage directory exists
      try {
        await fs.mkdir(storageDir, { recursive: true });
      } catch (err) {
        // Directory already exists, ignore
      }

      const form = new IncomingForm({
        uploadDir: storageDir,
        keepExtensions: false,
        maxFileSize: 50 * 1024 * 1024, // 50MB
        filename: (name, ext, part) => {
          // Generate unique filename like PHP does
          const uniqueName = crypto.randomBytes(16).toString('hex');
          const extension = path.extname(part.originalFilename || '');
          return uniqueName + extension;
        }
      });

      form.parse(req, async (err, fields, files) => {
        if (err) {
          console.error('File upload error:', err);
          send(res, 500, 'text/plain', 'Upload error: ' + err.message);
          return;
        }

        try {
          const file = files.file;
          if (!file) {
            send(res, 400, 'text/plain', 'No file uploaded');
            return;
          }

          const uploadedFile = Array.isArray(file) ? file[0] : file;
          const uniqueFileName = path.basename(uploadedFile.filepath);
          const extension = path.extname(uploadedFile.originalFilename || '').toLowerCase();

          console.log('File uploaded successfully:', uniqueFileName);

          // Detect file type from extension (like PHP fallback)
          let type = 'application';
          const ext = extension.replace('.', '');
          
          if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'].includes(ext)) {
            type = 'image';
          } else if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm'].includes(ext)) {
            type = 'video';
          } else if (['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'].includes(ext)) {
            type = 'audio';
          } else if (['txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx'].includes(ext)) {
            type = 'application';
          }

          const time = Math.floor(Date.now() / 1000);
          const roundedTime = roundTimestamp(time, 30);
          const messageId = generateMessageId(uniqueFileName, roundedTime);

          // Check for duplicates
          const messages = gossipSync.getMessages();
          if (messageExists(messages, messageId)) {
            // Delete the uploaded file
            try {
              await fs.unlink(uploadedFile.filepath);
            } catch (e) {
              console.error('Error deleting duplicate file:', e);
            }
            send(res, 200, 'text/plain', 'DUPLICATE');
            return;
          }

          // Add message with the unique filename
          const message = {
            id: messageId,
            type: type,
            content: uniqueFileName,
            time: roundedTime
          };

          gossipSync.messages.unshift(message);
          await gossipSync.saveMessages();
          
          console.log(`File message added: ${type} - ${uniqueFileName}`);
          send(res, 200, 'text/plain', 'OK');
        } catch (error) {
          console.error('Error processing upload:', error);
          send(res, 500, 'text/plain', 'Failed to process file: ' + error.message);
        }
      });
      return; // formidable handles the response
    }
    // Gossip API Routes
    else if (pathname === '/api/messages' && req.method === 'GET') {
      const messages = gossipSync.getMessages();
      sendJSON(res, 200, { messages, count: messages.length });
    }
    else if (pathname === '/api/sync/status' && req.method === 'GET') {
      const peers = Array.from(gossipSync.knownPeers.entries()).map(([id, lastSeen]) => ({
        peerId: id.substring(0, 8),
        lastSeen: new Date(lastSeen).toISOString(),
        isActive: Date.now() - lastSeen < gossipSync.gossipInterval * 3
      }));

      sendJSON(res, 200, {
        peerId: gossipSync.peerId,
        messageCount: gossipSync.messages.length,
        fileHash: gossipSync.fileHash?.substring(0, 16),
        connectedPeers: peers.length,
        peers
      });
    }
    // Static file serving
    else {
      let filePath = pathname === '/' ? '/index.html' : pathname;
      
      // Serve from root for these paths
      if (pathname.startsWith('/images/') || 
          pathname.startsWith('/files/') ||
          pathname.startsWith('/storage/') ||
          pathname === '/script.js') {
        filePath = path.join(__dirname, filePath);
      } else {
        // Serve other files from public folder
        filePath = path.join(__dirname, 'public', filePath);
      }
      
      await serveFile(res, filePath);
    }
  } catch (err) {
    console.error('Request error:', err);
    send(res, 500, 'text/plain', 'Internal server error');
  }
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🚀 Server running on http://localhost:${PORT}`);
  console.log(`\n📡 Gossip Protocol Active`);
  console.log(`   Peer ID: ${gossipSync.peerId}`);
  console.log(`   Broadcast Port: ${gossipSync.broadcastPort}`);
  console.log(`\n✅ All PHP endpoints converted to Node.js`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n\nShutting down gracefully...');
  gossipSync.stop();
  server.close();
  process.exit(0);
});