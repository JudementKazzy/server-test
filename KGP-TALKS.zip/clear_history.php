<?php
/**
 * Clear all chat history
 * Deletes all messages from msg.json and optionally uploaded files
 */

$msgPath = "storage/msg.json";

// Read existing messages to get file references
$data = [];
if (file_exists($msgPath)) {
    $content = file_get_contents($msgPath);
    $data = json_decode($content, true) ?: [];
}

// Delete uploaded files (images, videos, audio, etc.)
$filesDeleted = 0;
foreach ($data as $message) {
    if (isset($message['content']) && $message['type'] !== 'text') {
        $filePath = "storage/" . $message['content'];
        if (file_exists($filePath)) {
            if (unlink($filePath)) {
                $filesDeleted++;
            }
        }
    }
}

// Clear the message history (write empty array)
$result = file_put_contents($msgPath, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);

if ($result !== false) {
    error_log("Chat history cleared. Deleted $filesDeleted files.");
    echo "OK";
} else {
    http_response_code(500);
    echo "Failed to clear history";
}
?>