const express = require('express');
const GossipSync = require('./gossip-sync');
const path = require('path');

const app = express();
app.use(express.json());

// Initialize Gossip Sync
const gossipSync = new GossipSync({
  filePath: path.join(__dirname, 'storage', 'msg.json'),
  gossipInterval: 5000,
  port: 41234,
  broadcastPort: 41235
});

// Start gossip sync
gossipSync.init().then(() => {
  console.log('Gossip sync initialized');
}).catch(err => {
  console.error('Failed to initialize gossip sync:', err);
});

// API endpoint to get all messages
app.get('/api/messages', (req, res) => {
  const messages = gossipSync.getMessages();
  res.json({ messages, count: messages.length });
});

// API endpoint to add a new message
app.post('/api/messages', async (req, res) => {
  try {
    const { content, type, ...metadata } = req.body;
    
    if (!content) {
      return res.status(400).json({ error: 'Content is required' });
    }

    const message = await gossipSync.addMessage(
      content, 
      type || 'text', 
      metadata
    );
    
    res.status(201).json({ 
      success: true, 
      message 
    });
  } catch (err) {
    console.error('Error adding message:', err);
    res.status(500).json({ error: 'Failed to add message' });
  }
});

// API endpoint to check sync status
app.get('/api/sync/status', (req, res) => {
  const peers = Array.from(gossipSync.knownPeers.entries()).map(([id, lastSeen]) => ({
    peerId: id.substring(0, 8),
    lastSeen: new Date(lastSeen).toISOString(),
    isActive: Date.now() - lastSeen < gossipSync.gossipInterval * 3
  }));

  res.json({
    peerId: gossipSync.peerId,
    messageCount: gossipSync.messages.length,
    fileHash: gossipSync.fileHash?.substring(0, 16),
    connectedPeers: peers.length,
    peers
  });
});

// Start HTTP server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`HTTP server running on port ${PORT}`);
  console.log(`\nAPI Endpoints:`);
  console.log(`  GET  http://localhost:${PORT}/api/messages`);
  console.log(`  POST http://localhost:${PORT}/api/messages`);
  console.log(`  GET  http://localhost:${PORT}/api/sync/status`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down...');
  gossipSync.stop();
  process.exit(0);
});