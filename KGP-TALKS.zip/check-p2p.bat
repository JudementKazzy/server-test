@echo off
title KGP Talks - Setup Checker
color 0B

echo.
echo  ========================================
echo     KGP TALKS - P2P SETUP CHECKER
echo  ========================================
echo.

REM Check Node.js
echo [1/5] Checking Node.js...
where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo       [OK] Node.js found
    node --version
) else (
    echo       [FAIL] Node.js not installed
    echo       Download from: https://nodejs.org
)
echo.

REM Check dependencies
echo [2/5] Checking dependencies...
if exist "node_modules\formidable\" (
    echo       [OK] Formidable installed
) else (
    echo       [FAIL] Dependencies missing
    echo       Run: npm install formidable
)
echo.

REM Check files
echo [3/5] Checking required files...
if exist "server-no-express.js" (
    echo       [OK] server-no-express.js
) else (
    echo       [FAIL] server-no-express.js missing
)
if exist "gossip-sync.js" (
    echo       [OK] gossip-sync.js
) else (
    echo       [FAIL] gossip-sync.js missing
)
echo.

REM Check firewall
echo [4/5] Checking firewall...
netsh advfirewall firewall show rule name="KGP Talks P2P Sync" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo       [OK] Firewall rule exists
) else (
    echo       [WARNING] Firewall rule not found
    echo       Run launch-kgp-talks.bat as Administrator
)
echo.

REM Get network info
echo [5/5] Network information...
set LOCAL_IP=Not found
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4" ^| findstr /v "127.0.0.1"') do (
    set LOCAL_IP=%%a
    goto :ip_found
)
:ip_found
set LOCAL_IP=%LOCAL_IP:~1%
echo       Your IP: %LOCAL_IP%
echo       Access URL: http://%LOCAL_IP%:3000
echo.

REM Check if gossip-sync.js has new code
echo [BONUS] Checking gossip-sync.js version...
findstr /C:"RECEIVED REQUEST" gossip-sync.js >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo       [OK] Using updated gossip protocol
) else (
    echo       [WARNING] Old gossip-sync.js detected
    echo       Update gossip-sync.js with the latest version
)
echo.

echo  ========================================
echo.
echo  READY TO START?
echo.
echo  Run: launch-kgp-talks.bat (as Administrator)
echo.
echo  ========================================
echo.
pause