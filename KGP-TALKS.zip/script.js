document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('main');
    const clearHistoryBtn = document.getElementById('clear-history-btn');
    
    // Clear history button handler
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear all chat history? This cannot be undone.')) {
                fetch('/clear_history.php', {
                    method: 'POST'
                })
                .then(response => response.text())
                .then(result => {
                    if (result === 'OK') {
                        updatechatbox();
                    } else {
                        alert('Failed to clear history: ' + result);
                    }
                })
                .catch(error => {
                    console.error('Error clearing history:', error);
                    alert('Error clearing history');
                });
            }
        });
    }
    
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
       
        const messageInput = document.getElementById('message');
        const fileInput = document.getElementById('files');
        const messageText = messageInput.value.trim();
        const file = fileInput.files[0];
        
        // Handle text message
        if (messageText !== '') {
            try {
                await fetch('./save_message.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'text=' + encodeURIComponent(messageText)
                });
                messageInput.value = '';
            } catch (error) {
                console.error('Error sending message:', error);
            }
        }
        
        // Handle file upload
        if (file) {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('fileType', file.type);
            
            try {
                await fetch('./file_upload.php', {
                    method: 'POST',
                    body: formData
                });
                fileInput.value = '';
            } catch (error) {
                console.error('Error uploading file:', error);
            }
        }
        
        // Update chatbox after both operations complete
        updatechatbox();
    });
    
    function updatechatbox() {
        console.log('Fetching messages...');
        
        // Use absolute URL
        fetch('/get_message.php')
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text(); // Get as text first to see what we're getting
            })
            .then(text => {
                console.log('Raw response:', text);
                return JSON.parse(text); // Then parse it
            })
            .then(data => {
                console.log('Parsed data:', data);
                
                const chatBox = document.querySelector('#chat-box');
                
                if (!chatBox) {
                    console.error('Chat box element not found');
                    return;
                }
                
                console.log('Chat box found, clearing content');
                chatBox.innerHTML = '';
                
                if (!Array.isArray(data)) {
                    console.error('Expected array but got:', typeof data, data);
                    return;
                }
                
                console.log('Processing', data.length, 'messages');
                
                if (data.length === 0) {
                    chatBox.innerHTML = '<p style="color: #999; padding: 20px;">No messages yet. Send a message to get started!</p>';
                    return;
                }
                
                data.forEach((item, index) => {
                    console.log('Processing message', index, ':', item);
                    
                    const messageElement = document.createElement('div');
                    messageElement.style.marginBottom = '10px';
                    messageElement.style.padding = '8px';
                    messageElement.style.backgroundColor = '#415056';
                    messageElement.style.borderRadius = '5px';
                    
                    const date = new Date(item.time * 1000);
                    const timeStr = date.toLocaleTimeString();
                    
                    if (item.type === 'text') {
                        // SECURITY: Use textContent to prevent XSS
                        const timePrefix = document.createTextNode(`[${timeStr}] `);
                        messageElement.appendChild(timePrefix);
                        const contentText = document.createTextNode(item.content);
                        messageElement.appendChild(contentText);
                        console.log('Created text message element');
                    } else if (item.type === 'image') {
                        const timeText = document.createTextNode(`[${timeStr}] `);
                        messageElement.appendChild(timeText);
                        const img = document.createElement('img');
                        img.src = 'storage/' + encodeURIComponent(item.content);
                        img.alt = 'Image';
                        img.style.maxWidth = '300px';
                        img.style.maxHeight = '300px';
                        img.style.display = 'block';
                        img.style.marginTop = '5px';
                        messageElement.appendChild(img);
                    } else if (item.type === 'video') {
                        const timeText = document.createTextNode(`[${timeStr}] `);
                        messageElement.appendChild(timeText);
                        const video = document.createElement('video');
                        video.controls = true;
                        video.style.maxWidth = '400px';
                        video.style.display = 'block';
                        video.style.marginTop = '5px';
                        const source = document.createElement('source');
                        source.src = 'storage/' + encodeURIComponent(item.content);
                        source.type = 'video/mp4';
                        video.appendChild(source);
                        messageElement.appendChild(video);
                    } else if (item.type === 'audio') {
                        const timeText = document.createTextNode(`[${timeStr}] `);
                        messageElement.appendChild(timeText);
                        const audio = document.createElement('audio');
                        audio.controls = true;
                        audio.style.display = 'block';
                        audio.style.marginTop = '5px';
                        const source = document.createElement('source');
                        source.src = 'storage/' + encodeURIComponent(item.content);
                        audio.appendChild(source);
                        messageElement.appendChild(audio);
                    } else {
                        const timeText = document.createTextNode(`[${timeStr}] `);
                        messageElement.appendChild(timeText);
                        const link = document.createElement('a');
                        link.href = 'storage/' + encodeURIComponent(item.content);
                        link.download = '';
                        link.style.color = '#007bff';
                        link.style.textDecoration = 'underline';
                        link.textContent = '📎 Download File';
                        messageElement.appendChild(link);
                    }
                    
                    chatBox.appendChild(messageElement);
                    console.log('Appended message element to chat box');
                });
                
                console.log('Chat box update complete. Total children:', chatBox.children.length);
            })
            .catch(error => {
                console.error('Error updating chatbox:', error);
            });
    }
    
    // Initial chatbox update
    updatechatbox();
    
    // Optional: Auto-refresh every 3 seconds to get new messages
    setInterval(updatechatbox, 3000);
});