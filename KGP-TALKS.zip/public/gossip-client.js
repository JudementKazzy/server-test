// Frontend client for Gossip Sync
// This runs in the browser and communicates with your Node.js server

class GossipClient {
  constructor(serverUrl = '') {
    this.serverUrl = serverUrl;
    this.messages = [];
    this.syncStatus = null;
    this.pollInterval = null;
  }

  // Fetch all messages from the server
  async getMessages() {
    try {
      const response = await fetch(`${this.serverUrl}/api/messages`);
      if (!response.ok) throw new Error('Failed to fetch messages');
      
      const data = await response.json();
      this.messages = data.messages || [];
      return this.messages;
    } catch (err) {
      console.error('Error fetching messages:', err);
      throw err;
    }
  }

  // Add a new message
  async addMessage(content, type = 'text', metadata = {}) {
    try {
      const response = await fetch(`${this.serverUrl}/api/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ content, type, ...metadata })
      });

      if (!response.ok) throw new Error('Failed to add message');
      
      const data = await response.json();
      
      // Refresh messages after adding
      await this.getMessages();
      
      return data.message;
    } catch (err) {
      console.error('Error adding message:', err);
      throw err;
    }
  }

  // Get sync status (how many peers are connected, etc.)
  async getSyncStatus() {
    try {
      const response = await fetch(`${this.serverUrl}/api/sync/status`);
      if (!response.ok) throw new Error('Failed to fetch sync status');
      
      this.syncStatus = await response.json();
      return this.syncStatus;
    } catch (err) {
      console.error('Error fetching sync status:', err);
      throw err;
    }
  }

  // Start auto-polling for updates (checks for new messages every interval)
  startPolling(intervalMs = 3000, onUpdate = null) {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
    }

    this.pollInterval = setInterval(async () => {
      const oldCount = this.messages.length;
      await this.getMessages();
      
      if (onUpdate && this.messages.length !== oldCount) {
        onUpdate(this.messages);
      }
    }, intervalMs);

    console.log(`Started polling for updates every ${intervalMs}ms`);
  }

  // Stop auto-polling
  stopPolling() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
      console.log('Stopped polling');
    }
  }

  // Format timestamp for display
  formatTime(unixTimestamp) {
    const date = new Date(unixTimestamp * 1000);
    return date.toLocaleString();
  }
}

// Make it available globally
window.GossipClient = GossipClient;

// Auto-initialize if desired
if (typeof window !== 'undefined') {
  window.gossipClient = new GossipClient();
  console.log('Gossip Client initialized. Use window.gossipClient to interact.');
}