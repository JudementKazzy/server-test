<?php
/**
 * Generate a unique anonymous message ID
 */
function generateMessageId($content, $timestamp) {
    $random = bin2hex(random_bytes(16));
    $data = $content . $timestamp . $random;
    return hash('sha256', $data);
}
/**
 * Round timestamp to nearest interval (for anonymity)
 */
function roundTimestamp($timestamp, $interval = 30) {
    return floor($timestamp / $interval) * $interval;
}
/**
 * Check if message ID already exists (deduplication)
 */
function messageExists($messages, $id) {
    foreach ($messages as $msg) {
        if (isset($msg['id']) && $msg['id'] === $id) {
            return true;
        }
    }
    return false;
}
if (isset($_POST["text"])) {
    $text = trim($_POST["text"]);
   
    // Round timestamp for anonymity
    $time = time();
    $roundedTime = roundTimestamp($time, 30); // Round to 30 seconds
   
    // Generate unique anonymous ID
    $messageId = generateMessageId($text, $roundedTime);
   
    $path = __DIR__ . "/storage/msg.json";
   
    // Read existing messages
    $content = file_get_contents($path);
    $data = json_decode($content, true);
    if (!$data) $data = [];
   
    // Check for duplicates
    if (messageExists($data, $messageId)) {
        echo "DUPLICATE"; // Message already exists
        exit;
    }
   
    // Create new message with ID
    $newMessage = [
        "id" => $messageId,
        "type" => "text",  // Changed from "plain" to "text"
        "content" => $text,
        "time" => $roundedTime
    ];
   
    // Add to beginning of array
    array_unshift($data, $newMessage);
   
    // Optional: Limit message history (e.g., last 1000 messages)
    if (count($data) > 1000) {
        $data = array_slice($data, 0, 1000);
    }
   
    // Save to file
    if (file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT)) === false) {
        http_response_code(500);
        echo "Failed to write JSON";
    } else {
        echo "OK";
    }
}
?>